#ifndef COMMUNICATION_H
#define COMMUNICATION_H

void initializeCommunication();
void handleCommunication();
void sendDataToPi();

#endif
