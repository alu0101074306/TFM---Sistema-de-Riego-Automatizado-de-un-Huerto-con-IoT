#ifndef DISPLAY_H
#define DISPLAY_H

void initializeDisplay();
void displayMenu();

#endif
