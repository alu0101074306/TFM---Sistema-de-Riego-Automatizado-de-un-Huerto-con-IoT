#ifndef BUTTON_H
#define BUTTON_H

void initializeButton();
void buttonISR();

#endif
