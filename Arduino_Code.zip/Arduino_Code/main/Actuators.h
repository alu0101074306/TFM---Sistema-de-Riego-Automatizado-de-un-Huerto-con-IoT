#ifndef ACTUATORS_H
#define ACTUATORS_H

void initializeActuators();

#endif
